"""Participant bot package."""
